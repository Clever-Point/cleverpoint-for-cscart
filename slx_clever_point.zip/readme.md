### Οδηγίες εγκατάστασης

##### Βήμα 1

![00-clever1.jpg](doc/00-clever1.jpg)

##### Βήμα 2

![01-clever2.jpg](doc/01-clever2.jpg)

##### Βήμα 3

![02-clever3.jpg](doc/02-clever3.jpg)

##### Βήμα 4

![04-clever4.jpg](doc/04-clever4.jpg)

### Παραμετροποίηση

##### Βήμα 1 - Καρτέλα Βασικές ρυθμίσεις - Γενικά

![05-clever_params1.jpg](doc/05-clever_params1.jpg)

##### Βήμα 2 - Καρτέλα Βασικές ρυθμίσεις - Εμφάνιση

![06-clever_params2.jpg](doc/06-clever_params2.jpg)

##### Βήμα 3 - Καρτέλα Βασικές ρυθμίσεις - Παραγγελίες

![07-clever_params3.jpg](doc/07-clever_params3.jpg)

##### Βήμα 4 - Καρτέλα Βασικές ρυθμίσεις - Πεδία παραλήπτη

![08-clever_params4.jpg](doc/08-clever_params4.jpg)

### Εμφάνιση χάρτη κατά το checkout πελάτη (frontend-modal)

![16-clever_point_popup.jpg](doc/16-clever_point_popup.jpg)

![17-clever_point_modal.jpg](doc/17-clever_point_modal.jpg)

### Εμφάνιση χάρτη κατά το checkout πελάτη litecheckout (frontend)

![09-clever_checkoutpage.jpg](doc/09-clever_checkoutpage.jpg)

### Εμφάνιση χάρτη κατά το checkout πελάτη step by step checkout (frontend)

![12-clever_checkoutpage_stepbystep.jpg](doc/12-clever_checkoutpage_stepbystep.jpg)

### Εμφάνιση στην παραγγελία του πελάτη μετά την ολοκλήρωση της παραγγελίας (frontend)

![11-clever_view_order_page.jpg](doc/11-clever_view_order_page.jpg)

### Εμφάνιση στη διαχείριση παραγγελιών (backend)

![10-clever_view_admin_order_page.jpg](doc/10-clever_view_admin_order_page.jpg)

### Προσθήκη κώδικα στα e-mail templates

Για να εμφανίζεται το σημείο παραλαβής της Cleverpoint στο αντίγραφο παραγγελίας πρέπει να προστεθεί το παρακάτω κομμάτι κώδικα στο αντίστοιχο Email template

![13-customer-notifications1.jpg](doc/13-customer-notifications1.jpg)

![14-customer-notifications2.jpg](doc/14-customer-notifications2.jpg)

![15-customer-notifications3.jpg](doc/15-customer-notifications3.jpg)

```twig
{% for pg in o.product_groups %}
{% if pg.clever_point_params %}
<p style="color: #787878; font-size: 14px; font-family: Helvetica, Arial, sans-serif; padding-bottom: 5px; margin: 0px;">{{ __("slx_clever_point.clever_point") }}:</p>
    <ul>
    <li>{{ pg.clever_point_params.point.ShortName }}</li>
    <li>{{ __("slx_clever_point.address") }}: {{ pg.clever_point_params.point.AddressLine1 }}, {{ pg.clever_point_params.point.City }}</li>
    <li>{{__("slx_clever_point.phone")}}: {{ pg.clever_point_params.point.Phones }}</li>
    <li>{{__("slx_clever_point.work_hours")}}: {% for wk in pg.clever_point_params.point.WorkHoursFormattedWithDaysV2 %}{{ wk}} {% endfor %}</li>
    </ul>
{% endif %}
{% endfor %}
```
